/************
Student Name: Dae Sung, Mukesh Rathore
File Name: ReadMe
Assignment Number: Project 1
************/

INSTRUCTIONS:
In order to run the java file, open the Windows PowerShell or CommandPrompt in the containing folder "...COP5518-Group11-Project1\MTCollatz\src"
Run command "java MTCollatz [range N] [threads T]" i.e. "java MTCollatz 10000 8"
Optionally "java MTCollatz [range N] [threads T] 2> results.csv" to get output of Range R, threads T, and runtime in milliseconds.
Optionally "java MTCollatz [range N] [threads T] > results.csv" to get output of stop times as csv file.

Note:
The compiled files are already created, in order to recompile, you can delete MTCollatz.class in the ..\src folder, and DataSet.class, DataSetHelper.class in ..\src\MTCollatzPackage